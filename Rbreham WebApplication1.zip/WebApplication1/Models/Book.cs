﻿namespace WebApplication1.Models
{
    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string NumISBN { get; set; } = string.Empty;
        public int NumPage { get; set; }
        public string Summary { get; set; } = string.Empty;
        public int AuthorId { get; set; }
    }
}
