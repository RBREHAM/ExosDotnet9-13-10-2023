﻿using System.Collections.Generic;
using System.Reflection;

namespace WebApplication1.Models.Services
{
    public class Service
    {
        //public Service()
        //{
        //    List<Author> AuthorList = new List<Author>
        //    {
        //        new Author {Id = 1, Name = "Raphael", Surname = "Breham", PublishingHouse = "British News"},
        //        new Author { Id = 2, Name = "Jules", Surname = "Bellien", PublishingHouse = "Gamerz"},
        //        new Author { Id = 3, Name = "Maurice", Surname = "Leblanc", PublishingHouse = "Le Parisien"},
        //    };

        //    List<Book> ListBooks = new List<Book> {
        //        new Book { Id = 1, NumISBN = "0-5427-9369-5", NumPage = 210, Summary = "Blablabla", AuthorId = 1}, 
        //        new Book { Id = 2, NumISBN = "0-1194-6577-9", NumPage = 352, Summary = "Blablabla", AuthorId = 3}, 
        //        new Book { Id = 3, NumISBN = "0-5718-3419-1", NumPage = 145, Summary = "Blablabla", AuthorId = 2}, 
        //        new Book { Id = 4, NumISBN = "0-5740-0097-6", NumPage = 263, Summary = "Blablabla", AuthorId = 1}, 
        //        new Book { Id = 5, NumISBN = "0-7951-9083-2", NumPage = 195, Summary = "Blablabla", AuthorId = 3}, 
        //    };
        //}

        public List<Book> GetBooks()
        {
            List<Book> ListBooks = new List<Book> {
                new Book { Id = 1, Title = "Euro VS Pounds : the great debate", NumISBN = "0-5427-9369-5", NumPage = 210, Summary = "Blablabla", AuthorId = 1},
                new Book { Id = 2, Title = "Arsene Lupin : La perle noir", NumISBN = "0-1194-6577-9", NumPage = 352, Summary = "Blablabla", AuthorId = 3},
                new Book { Id = 3, Title = "Minecraft4life", NumISBN = "0-5718-3419-1", NumPage = 145, Summary = "Blablabla", AuthorId = 2},
                new Book { Id = 4, Title = "TeaTime Stories", NumISBN = "0-5740-0097-6", NumPage = 263, Summary = "Blablabla", AuthorId = 1},
                new Book { Id = 5, Title = "Arsene Lupin : Omar Sy", NumISBN = "0-7951-9083-2", NumPage = 195, Summary = "Blablabla", AuthorId = 3},
            };
            return ListBooks;
        }

        public List<Author> GetAuthors()
        {
            List<Author> AuthorList = new List<Author>
            {
                new Author {Id = 1, Name = "Raphael", Surname = "Breham", PublishingHouse = "British News"},
                new Author { Id = 2, Name = "Jules", Surname = "Bellien", PublishingHouse = "Gamerz"},
                new Author { Id = 3, Name = "Maurice", Surname = "Leblanc", PublishingHouse = "Le Parisien"},
            };
            return AuthorList;
        }
    }
}
