﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class VoitureController : Controller
    {
        // GET: VoitureController
        public ActionResult Accueil()
        {
            return View();
        }

        [Route("news/{year:int?}/{month:validmonth?}")]
        public ActionResult News(int year, int month)
        {
            return View(
                new CurrentDate { 
                Year = year, 
                Month = month 
                }
             );
        }

        public record CurrentDate
        {
            public int Year { get; set; } = DateTime.Now.Year;
            public int Month { get; set; } = DateTime.Now.Month;
        }

        // GET: VoitureController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: VoitureController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: VoitureController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: VoitureController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: VoitureController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: VoitureController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: VoitureController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
