﻿namespace WebApplication2.CustomConstraits
{
    public class ValidMonthRouteConstraint : IRouteConstraint
    {
        public bool Match(HttpContext? httpContext, IRouter? route, string routeKey, RouteValueDictionary values, RouteDirection routeDirection)
        {
            if (values.TryGetValue(routeKey, out var value) && value != null)
            {
                if (int.TryParse(value.ToString(), out int intValue))
                {
                    return (0 < intValue && intValue <= 12); // Vérifie si la valeur est enter 1 et 12.
                }
            }

            return false; // La valeur du paramètre ne correspond pas à un entier positif.
        }
    }
}
