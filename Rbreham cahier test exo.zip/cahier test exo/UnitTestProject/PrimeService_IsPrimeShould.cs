using Prime.Services;

namespace UnitTestProject
{
    [TestFixture]
    public class PrimeService_IsPrimeShould
    {
        private PrimeService _primeService;

        [SetUp]
        public void Setup()
        {
            _primeService = new PrimeService();
        }

        [Test]
        public void Test1()
        {
            var result = _primeService.IsPrime(2);

            Assert.IsFalse(result, "Number input should be smaller than 2");
        }
    }
}