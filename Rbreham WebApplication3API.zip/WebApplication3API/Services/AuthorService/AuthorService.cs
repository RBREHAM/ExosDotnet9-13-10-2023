﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication3API.Data;
using WebApplication3API.Models;
using WebApplication3API.Services.AuthorService;

namespace WebApplication3API.Services.AuthorService
{
    public class AuthorService : IAuthorService
    {
        private readonly DataContext _dataContext;

        public AuthorService(DataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public async Task<List<Author>> GetAllAuthorsAsync()
        {
            return await _dataContext.Authors.ToListAsync();
        }

        public async Task<Author> GetAuthorByIdAsync(int id)
        {
            return await _dataContext.Authors.FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task<Author> CreateAuthorAsync(Author author)
        {
            _dataContext.Authors.Add(author);
            await _dataContext.SaveChangesAsync();
            return author;
        }

        public async Task<Author> UpdateAuthorAsync(Author author)
        {
            var existingAuthor = await _dataContext.Authors.FindAsync(author.Id);
            if (existingAuthor == null)
            {
                return null; // Handle the error appropriately
            }

            existingAuthor.Name = author.Name;
            existingAuthor.Surname = author.Surname;
            existingAuthor.Birthday = author.Birthday;

            await _dataContext.SaveChangesAsync();
            return existingAuthor;
        }

        public async Task<Author> DeleteAuthorAsync(int id)
        {
            var author = await _dataContext.Authors.FirstOrDefaultAsync(a => a.Id == id);
            if (author != null)
            {
                _dataContext.Authors.Remove(author);
                await _dataContext.SaveChangesAsync();
            }
            return author;
        }
    }
}
