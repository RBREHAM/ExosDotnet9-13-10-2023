﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication3API.Models;

namespace WebApplication3API.Services.AuthorService
{
    public interface IAuthorService
    {
        Task<List<Author>> GetAllAuthorsAsync();
        Task<Author> GetAuthorByIdAsync(int id);
        Task<Author> CreateAuthorAsync(Author author);
        Task<Author> UpdateAuthorAsync(Author author);
        Task<Author> DeleteAuthorAsync(int id);
    }
}
