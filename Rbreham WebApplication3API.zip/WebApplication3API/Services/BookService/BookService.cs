﻿using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication3API.Models;

namespace WebApplication3API.Services.BookService
{
    public interface IBookService
    {
        Task<List<Book>> GetAllBooksAsync();
        Task<Book> GetBookByIdAsync(int id);
        Task<Book> CreateBookAsync(Book book);
        Task<Book> UpdateBookAsync(Book book);
        Task<Book> DeleteBookAsync(int id);
    }
}
