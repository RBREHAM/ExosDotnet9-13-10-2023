﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication3API.Data;
using WebApplication3API.Models;
using WebApplication3API.Services.BookService;

namespace WebApplication3API.Services.BookService
{
    public class BookService : IBookService
    {
        private readonly DataContext _dataContext;

        public BookService(DataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public async Task<List<Book>> GetAllBooksAsync()
        {
            return await _dataContext.Books.ToListAsync();
        }

        public async Task<Book> GetBookByIdAsync(int id)
        {
            return await _dataContext.Books.FirstOrDefaultAsync(b => b.Id == id);
        }

        public async Task<Book> CreateBookAsync(Book book)
        {
            _dataContext.Books.Add(book);
            await _dataContext.SaveChangesAsync();
            return book;
        }

        public async Task<Book> UpdateBookAsync(Book book)
        {
            var existingBook = await _dataContext.Books.FindAsync(book.Id);
            if (existingBook == null)
            {
                return null; // Handle the error appropriately
            }

            existingBook.Titre = book.Titre;
            existingBook.AuthorId = book.AuthorId;
            existingBook.PublishDate = book.PublishDate;
            existingBook.Description = book.Description;

            await _dataContext.SaveChangesAsync();
            return existingBook;
        }

        public async Task<Book> DeleteBookAsync(int id)
        {
            var book = await _dataContext.Books.FirstOrDefaultAsync(b => b.Id == id);
            if (book != null)
            {
                _dataContext.Books.Remove(book);
                await _dataContext.SaveChangesAsync();
            }
            return book;
        }
    }
}
