﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication3API.Models;
using WebApplication3API.Services;
using WebApplication3API.Services.BookService;

namespace WebApplication3API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly IBookService _bookService;

        public BookController(IBookService bookService)
        {
            _bookService = bookService;
        }

        [HttpGet("[action]")]
        public async Task<ActionResult<List<Book>>> GetAllBooks()
        {
            var books = await _bookService.GetAllBooksAsync();
            return Ok(books);
        }

        [HttpGet("[action]/{id}")]
        public async Task<ActionResult<Book>> GetBookById(int id)
        {
            var book = await _bookService.GetBookByIdAsync(id);
            if (book == null)
            {
                return NotFound("Livre non trouvé");
            }
            return Ok(book);
        }

        [HttpPost("[action]")]
        public async Task<ActionResult<Book>> CreateBook(Book book)
        {
            var createdBook = await _bookService.CreateBookAsync(book);
            return Ok(createdBook);
        }

        [HttpPut("[action]")]
        public async Task<ActionResult<Book>> UpdateBook(Book book)
        {
            var updatedBook = await _bookService.UpdateBookAsync(book);
            if (updatedBook == null)
            {
                return NotFound("Livre non trouvé");
            }
            return Ok(updatedBook);
        }

        [HttpDelete("[action]/{id}")]
        public async Task<ActionResult<Book>> DeleteBook(int id)
        {
            var deletedBook = await _bookService.DeleteBookAsync(id);
            if (deletedBook == null)
            {
                return NotFound("Livre non trouvé");
            }
            return Ok(deletedBook);
        }
    }
}
