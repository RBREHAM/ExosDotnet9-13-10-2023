﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebApplication3API.Models;
using WebApplication3API.Services;
using WebApplication3API.Services.AuthorService;

namespace WebApplication3API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorController : ControllerBase
    {
        private readonly IAuthorService _authorService;

        public AuthorController(IAuthorService authorService)
        {
            _authorService = authorService;
        }

        [HttpGet("[action]")]
        public async Task<ActionResult<List<Author>>> GetAllAuthors()
        {
            var authors = await _authorService.GetAllAuthorsAsync();
            return Ok(authors);
        }

        [HttpGet("[action]/{id}")]
        public async Task<ActionResult<Author>> GetAuthorById(int id)
        {
            var author = await _authorService.GetAuthorByIdAsync(id);
            if (author == null)
            {
                return NotFound("Auteur non trouvé");
            }
            return Ok(author);
        }

        [HttpPost("[action]")]
        public async Task<ActionResult<Author>> CreateAuthor(Author author)
        {
            var createdAuthor = await _authorService.CreateAuthorAsync(author);
            return Ok(createdAuthor);
        }

        [HttpPut("[action]")]
        public async Task<ActionResult<Author>> UpdateAuthor(Author author)
        {
            var updatedAuthor = await _authorService.UpdateAuthorAsync(author);
            if (updatedAuthor == null)
            {
                return NotFound("Auteur non trouvé");
            }
            return Ok(updatedAuthor);
        }

        [HttpDelete("[action]/{id}")]
        public async Task<ActionResult<Author>> DeleteAuthor(int id)
        {
            var deletedAuthor = await _authorService.DeleteAuthorAsync(id);
            if (deletedAuthor == null)
            {
                return NotFound("Auteur non trouvé");
            }
            return Ok(deletedAuthor);
        }
    }
}
