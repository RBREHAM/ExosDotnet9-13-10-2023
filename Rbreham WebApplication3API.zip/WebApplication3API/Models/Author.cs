﻿using System.Text.Json.Serialization;

namespace WebApplication3API.Models
{
    public class Author
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Surname { get; set; } = string.Empty;
        public DateTime Birthday { get; set;}

        public List<Book>? Books { get; set; }
    }
}
